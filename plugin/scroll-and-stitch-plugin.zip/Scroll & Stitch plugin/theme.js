// Applies the remembered light/dark choice before the popup paints (no flash).
// A plain file because extension pages can't run inline scripts.
try {
  // Light unless the sun/moon button chose dark (Imraan, 19 Nov).
  var t = localStorage.getItem('sas.theme');
  document.documentElement.dataset.theme = t === 'dark' ? 'dark' : 'light';
} catch (e) {}
